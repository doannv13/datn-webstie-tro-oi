<?php

const DOT = '.';
const OBJECT_FACILITY = 'facility';
const OBJECT_USER ='admin/images/user';

const OBJECT_BANNER = 'banner';
const OBJECT_ADVERTISEMENT = 'advertisement';
const OBJECT_POST = 'post';

const HOME_URL='http://127.0.0.1:8000/';
const DETAIL_ROOM_URL='http://127.0.0.1:8000/room-post-detail/';
const DETAIL_POST_URL='http://127.0.0.1:8000/posts-detail/';



